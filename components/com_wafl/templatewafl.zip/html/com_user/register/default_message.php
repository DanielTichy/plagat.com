<?php // @version $Id: default_message.php 8944 2007-09-18 03:04:14Z friesengeist $
defined( '_JEXEC' ) or die( 'Restricted access' );
?>

<h3>
	<?php echo $this->message->title; ?>
</h3>

<p class="message">
	<?php echo $this->message->text; ?>
</p>
