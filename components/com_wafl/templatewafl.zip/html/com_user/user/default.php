<?php // @version $Id: default.php  $
defined('_JEXEC') or die('Restricted access');
?>

<h1 class="componentheading">
	<?php echo JText::_('Welcome!'); ?>
</h1>

<div class="contentdescription">
	<?php echo JText::_('WELCOME_DESC'); ?>
</div>
